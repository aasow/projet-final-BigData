import org.apache.spark.sql.DataFrame

object Load {

  /
  def saveData(df: DataFrame, saveMode: String, format: String, path: String): Unit = {
    try {
      df.write.format(format)
        .option("header", "true")
        .mode(saveMode)
        .save(path)
    } catch {
      case e: Exception =>
        Utils._log.error(s"Erreur lors de la sauvegarde des données au chemin $path avec le format $format : " + e.getMessage)
        throw e
    }
  }
}
