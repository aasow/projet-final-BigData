import org.apache.spark.sql.{DataFrame, functions => F}

object Transform {

  /**
   * Nettoyer les données brutes.
   */
  def cleanData(df: DataFrame): DataFrame = {
    // 0. Convertir les colonnes timestamp au format YYYY/MM/DD HH:MM:SS
    val dateFormatDF = df.columns.foldLeft(df) { (tempDF, colName) =>
      if (tempDF.schema(colName).dataType.simpleString == "timestamp") {
        tempDF.withColumn(colName, F.date_format(F.col(colName), "yyyy/MM/dd HH:mm:ss"))
      } else {
        tempDF
      }
    }

    // 1. Ajouter une colonne 'revenue' en extrayant 'ecommerce.purchase_revenue_in_usd'
    val revenueDF = dateFormatDF.withColumn("revenue", F.col("ecommerce.purchase_revenue_in_usd"))

    // 2. Filtrer les événements dont le revenu n'est pas null
    val purchasesDF = revenueDF.filter(F.col("revenue").isNotNull)

    // 3. Trouver les types d'événements uniques et compter combien il y en a
    val distinctEventsDF = purchasesDF.select("event_name").distinct()
    println(s"Nombre de types d'événements uniques: ${distinctEventsDF.count()}")

    // 4. Supprimer la colonne 'event_name'
    val cleanDF = purchasesDF.drop("event_name")

    cleanDF
  }

  /**
   * Calculer le revenu cumulé par source de trafic, état, et ville.
   * @param df : DataFrame
   * @return DataFrame
   */
  def computeTrafficRevenue(df: DataFrame): DataFrame = {
    // 5. Calculer la somme et la moyenne des revenus par source de trafic, état, et ville
    val trafficDF = df.groupBy("source", "state", "city")
      .agg(
        F.sum("revenue").as("total_rev"),
        F.avg("revenue").as("avg_rev")
      )

    // 6. Obtenir les cinq principales sources de trafic par revenu total
    val topTrafficDF = trafficDF.orderBy(F.desc("total_rev")).limit(5)

    // 7. Limiter les colonnes 'total_rev' et 'avg_rev' à deux décimales
    val finalDF = topTrafficDF
      .withColumn("total_rev", F.format_number(F.col("total_rev"), 2))
      .withColumn("avg_rev", F.format_number(F.col("avg_rev"), 2))

    finalDF
  }
}
