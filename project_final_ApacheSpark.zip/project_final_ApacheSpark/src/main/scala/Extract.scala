import org.apache.spark.sql.{DataFrame, SparkSession}

object Extract {

  
  def read_source_file(path: String, format: String): DataFrame = {
    try {
      val df = Utils._spark.read.format(format)
        .option("header", "true")
        .option("inferSchema", "true")
        .load(path)
      df
    } catch {
      case e: Exception =>
        Utils._log.error(s"Le chemin d'entrée est incorrect ou le format de fichier ne correspond pas aux données. " +
          s"Erreur : " + e.getMessage)
        throw e
    }
  }
}
