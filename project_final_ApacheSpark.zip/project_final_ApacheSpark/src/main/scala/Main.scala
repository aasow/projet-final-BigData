object Main {
  def main(args: Array[String]): Unit = {
    if (args.length != 2) {
      println("Arguments manquants.")
      println("Usage : Vous devez fournir le chemin du fichier source et le chemin de sortie.")
      System.exit(1)
    }

    // Obtenir les chemins du fichier JSON et de sortie depuis les arguments
    val jsonFilePath = args(0)
    val outputPath = args(1)

    // Lire le fichier source
    val df = Extract.read_source_file(jsonFilePath, "json")
    df.show()

    // Nettoyer les données
    val cleanDF = Transform.cleanData(df)
    cleanDF.show()

    // Calculer les revenus par source de trafic
    val transformDF = Transform.computeTrafficRevenue(cleanDF)
    transformDF.show()

    // Sauvegarder les données transformées
    Load.saveData(transformDF, "overwrite", "parquet", outputPath)
  }
}
